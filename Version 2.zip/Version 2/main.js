$(document).ready(function(){

    //Animation for size guide start
    window.onload = function() {

        var timeline = new TimelineMax();
        timeline.from("#stage", 0.4, {scale:0.5, opacity:0, ease:Power2.easeOut},"=+0.1")
        .from('.shirt1', 0.4, {scale:0.7, opacity:0, y:70},"=-0.2")
      }

    //Next slide after selecting country
    $('.option').click(function(){
        var timeline3 = new TimelineMax();
        timeline3.to("#select-box", 0.4, {scale:0.5, opacity:0, ease:Power1.easeOut},"=+0.2")
        .to('.frame1', 0.1, {opacity:0})
        .set('.frame2',{x:0, display:'block'})
        .from('.input_brand', 0.4, {opacity:0, y:30},"=+0.2")
        .from('#your_location', 0.4, {opacity:0, y:30},"=-0.1")
        .staggerFrom('.zaraBrand, .hmBrand, .addidasBrand', 0.4, {opacity:0, y:30},0.1,"=-0.4")
        // .to('.frame2', 0.7, {opacity:1, x:0, display:'block', scale:1, ease:Power2.easeOut},"=-0.1");
        displayRadioValue();
    })

    //Next slide after selecting brand
    $('#zara').click(function(){
        TweenMax.to('.input_brand', 0.3, {y:-26});
        TweenMax.to('.question2, #app-cover2', 0.7, {opacity:1, display:'block', delay: 0.7});
        TweenMax.to('.brand_container, #your_location', 0.7, {opacity:0});
        showZaraSize();
    })
    //Next slide after selecting brand
    $('#hm').click(function(){
        TweenMax.to('.input_brand', 0.3, {y:-26});
        TweenMax.to('.question2, #app-cover2', 0.7, {opacity:1, display:'block', delay: 0.7});
        TweenMax.to('.brand_container, #your_location', 0.7, {opacity:0});
        showHMSize();
    })
    //Next slide after selecting brand
    $('#addidas').click(function(){
        TweenMax.to('.input_brand', 0.3, {y:-26});
        TweenMax.to('.question2, #app-cover2', 0.7, {opacity:1, display:'block', delay: 0.7});
        TweenMax.to('.brand_container, #your_location', 0.7, {opacity:0});
        showAddidasSize();
    })

    //Next slide after selecting size from brand
    $('.option2').click(function(){

        var timeline4 = new TimelineMax();
        timeline4.staggerTo(".sizes-select, #your_brand", 0.3, {y:30, opacity:0, ease:Power1.easeOut},-0.1,"=+0.2")
        .to('.input_brand', 0.3, {y:20, opacity:0, ease:Power1.easeOut},"=-.1")
        .to('.frame2', 0.1, {opacity:0})
        .set('.frame3',{x:0, display:'block'})
        .from('.input_height', 0.4, {opacity:0, x:-204})
        .from('#height', 0.4, {opacity:0, x:204},"=-.4")
        .staggerFrom('.female_bodytypes input', 0.3, {opacity:0, top:30},0.1)
        .staggerFrom('.male_bodytypes input', 0.3, {opacity:0, top:30},-0.1, "=-0.3")
        // .to('.frame3', 0.7, {opacity:1, x:0, display:'block', scale:1, ease:Power2.easeOut},"=-0.1");

        // TweenMax.to('.frame2', 0.7, {x:50, opacity:0});
        // TweenMax.to('.frame3', 0.7, {x:0, display:'block', delay: 0.5});
    })
    //Next slide after selecting height + bodytype
    $('#submit_height').click(function(){
        var timeline5 = new TimelineMax();
        timeline5.to('.frame3', 0.7, {opacity:0})
        .to('.gears_container', 0.3, {display:'block'})
        .staggerFrom('.gear1, .gear2, .gear3', 0.3, {opacity:0, scale:0.5}, 0.1)
        .to('.gear1', 3, {rotation:100})
        .to('.gear2', 3, {rotation:-100},"=-3")
        .to('.gear3', 3, {rotation:100},"=-3")
        .staggerTo('.gear1, .gear2, .gear3', 0.3, {opacity:0, scale:0.5}, 0.1)
        .to('.frame4', 0.7, {x:0, display:'block', opacity:1})
        displayResult();
    })
    //Next slide after selecting height + bodytype
    $('.cta').click(function(){
        TweenMax.to('.frame4', 0.7, {x:50, opacity:0});
        TweenMax.to('.frame5', 0.7, {x:0, display:'block', delay: 0.5});

        var timeline6 = new TimelineMax();
        timeline6.from('#path', 0.4, {drawSVG: '0%'},"=+1")
        .fromTo('#check_path', 0.4, {drawSVG:"100% 100%"}, {drawSVG:"0% 100%"},"=-0.1")
        .from('.addedtocart', 0.3, {opacity:0, scale:0.5, ease:Power2.easeOut},"=-0.1")
        .to('.check_container', 0.4, {scale:0.5, opacity:0},"=+2")
        .to('.addedtocart', 0.4, {scale:0.5, opacity:0},"=-0.3")
        .from('.mixmatch_copy', 0.3, {opacity:0, x:-30})
        .from('.mix-and-match', 0.3, {opacity:0, x:-395},"=-0.15")
        .from('.model_base', 0.3, {opacity:0, rotationY:-180, scale:0.5},"=-0.1")
        .from('#model', 0.3, {opacity:0, y:-30},"=-0.1")
        .staggerFrom('.tuck, .untuck', 0.3, {opacity:0, y:10},0.1)
        .staggerFrom('.sizeup_container_tops div', 0.3, {opacity:0, y:10},0.1)

        if (femaleSelected === "isTrue"){
            console.log("if statement works");
            document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants.png'></img>"
            mixAndMatchFemale();
        }
        else if (MaleSelected === "isTrue"){
            console.log("if statement works");
            document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants_M.png'></img>"
            mixAndMatchMale();
        }
    })

    //change css if bodytype is selected and change back if another body is selected
    $('.bodytype').click(function(){
        var selectedItem = '#' +event.target.value;
        $('.bodytype').attr('data-selected', 'false');
        $(selectedItem).attr('data-selected', 'true');
    })

    var femaleSelected;
    var MaleSelected;

    //if female model selected show female body results
    $('#fXS, #fS, #fM, #fL, #fXL').click(function(){
        console.log('female clicked');
        femaleSelected = "isTrue";
        MaleSelected = "isFalse";
        console.log(femaleSelected);
        $('#female_body_results').css('display', 'block');
        $('#male_body_results').css('display', 'none');
        $('#female_body_results_TC').css('display', 'block');
        $('#male_body_results_TC').css('display', 'none');
    })
    //if male model selected show male body results
    $('#mXS, #mS, #mMedium, #mL, #mXL').click(function(){
        console.log('male clicked');
        femaleSelected = "isFalse";
        MaleSelected = "isTrue";
        $('#male_body_results').css('display', 'block');
        $('#female_body_results').css('display', 'none');
        $('#male_body_results_TC').css('display', 'block');
        $('#female_body_results_TC').css('display', 'none');
    })

    // mixAndMatchFemale();
    // mixAndMatchMale();

    function mixAndMatchFemale(){

        // if (document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants.png'></img>"){
        //     $('.size-M_tops').css('background-color', '#000000');
        //     $('.size-M_tops').css('color', 'white');
        //     $('.size-M_tops').css('border', '1px solid white');
        // }
        // else if (document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='shirt_XS.png'></img>"){
        //     $('.size-S_tops').css('background-color', '#000000');
        //     $('.size-S_tops').css('color', 'white');
        //     $('.size-S_tops').css('border', '1px solid white');
        // }

        var whiteShirtRedPants;
        var whiteShirtNoPants;
        var whiteShirtandShorts;

        var blackShirtRedPants;
        var blackShirtNoPants = "isTrue";
        var blackShirtandShorts;

        var tankNoPants;
        var tankRedPants;
        var tankShorts;

        $('.size-S_tops').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='shirt_XS.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_noPants_XS.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_noPants_XS.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants_XS.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts_XS.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_XS.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts_XS.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_XS.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_Shorts_XS.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            }
        })

        $('.size-M_tops').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_noPants.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_noPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants_medium' src='tank_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            }
        })

        $('.size-L_tops').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_Large' src='blackShirt_noPants_L.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_Large' src='whiteShirt_noPants_L.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_noPants_L.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsLarge' src='blackShirt_redPants_L.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_Large' src='blackShirt_Shorts_L.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsLarge' src='whiteShirt_redPants_L.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_Large' src='whiteShirt_Shorts_L.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_L.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_Shorts_L.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            }
        })

        $('.size-XL_tops').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XL' src='blackShirt_noPants_XL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XL' src='whiteShirt_noPants_XL.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_noPants_XL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsXL' src='blackShirt_redPants_XL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XL' src='blackShirt_Shorts_XL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsXL' src='whiteShirt_redPants_XL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XL' src='whiteShirt_Shorts_XL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_XL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_Shorts_XL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            }
        })

        $('.size-XXL_tops').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XXL' src='blackShirt_noPants_XXL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XXL' src='whiteShirt_noPants_XXL.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_noPants_XXL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsXXL' src='blackShirt_redPants_XXL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XXL' src='blackShirt_Shorts_XXL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsXXL' src='whiteShirt_redPants_XXL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XXL' src='whiteShirt_Shorts_XXL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_XXL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_Shorts_XXL.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            }
        })

        //tuck shirt
        $('.tuck').click(function(){
            if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants_tucked.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts_tucked.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_tucked.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts_tucked.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
        })

        //untuck shirt
        $('.untuck').click(function(){
            if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
        })
        //CLICK BLACK SHIRT OPTIONS
        $('.black_shirt').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
        })

        //CLICK WHITE SHIRT OPTIONS
        $('.white_shirt').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_noPants.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_noPants.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
        })

        //CLICK RED PANTS OPTIONS
        $('.red_pants').click(function(){
            if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants_medium' src='tank_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants_medium' src='tank_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFlase";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
                
        }) 

        //CLICK WHITE SHORTS OPTIONS
        $('.white_shorts').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            } 
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            } 
        })

        //CLICK BLACK TANK OPTIONS
        $('.black_tank').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_noPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_noPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants_medium' src='tank_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            } 
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants_medium' src='tank_redPants.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            } 
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='tank_Shorts.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            } 
        })
        
    }

    function mixAndMatchMale(){

        var whiteShirtRedPants;
        var whiteShirtNoPants;
        var whiteShirtandShorts;

        var blackShirtRedPants;
        var blackShirtNoPants = "isTrue";
        var blackShirtandShorts;

        var tankNoPants;
        var tankRedPants;
        var tankShorts;

        $('.size-S_tops').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_S_M' src='shirt_XS_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_S_M' src='whiteShirt_noPants_XS_M.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_S_M' src='tank_noPants_XS_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants_XS_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_S_M' src='blackShirt_Shorts_XS_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_XS_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_S_M' src='whiteShirt_Shorts_XS_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_XS_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_S_M' src='tank_Shorts_XS_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            }
        })

        $('.size-M_tops').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_noPants_M.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_noPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            }
        })

        $('.size-L_tops').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_Large' src='blackShirt_noPants_L_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_Large' src='whiteShirt_noPants_L_M.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_noPants_L_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsLarge' src='blackShirt_redPants_L_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_Large' src='blackShirt_Shorts_L_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsLarge' src='whiteShirt_redPants_L_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_Large' src='whiteShirt_Shorts_L_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_L_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_Shorts_L_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            }
        })

        $('.size-XL_tops').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XL' src='blackShirt_noPants_XL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XL' src='whiteShirt_noPants_XL_M.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_noPants_XL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsXL' src='blackShirt_redPants_XL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XL' src='blackShirt_Shorts_XL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsXL' src='whiteShirt_redPants_XL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XL' src='whiteShirt_Shorts_XL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_XL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_Shorts_XL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            }
        })

        $('.size-XXL_tops').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XXL' src='blackShirt_noPants_XXL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XXL' src='whiteShirt_noPants_XXL_M.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_noPants_XXL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsXXL' src='blackShirt_redPants_XXL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XXL' src='blackShirt_Shorts_XXL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpantsXXL' src='whiteShirt_redPants_XXL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_XXL' src='whiteShirt_Shorts_XXL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_XXL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_Shorts_XXL_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            }
        })

        //tuck shirt
        $('.tuck').click(function(){
            if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants_M_tucked.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts_M_tucked.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_M_tucked.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts_M_tucked.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
        })

        //untuck shirt
        $('.untuck').click(function(){
            if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
        })
        //CLICK BLACK SHIRT OPTIONS
        $('.black_shirt').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_noPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isTrue";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
        })

        //CLICK WHITE SHIRT OPTIONS
        $('.white_shirt').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_noPants_M.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_noPants_M.png'></img>"
                whiteShirtNoPants = "isTrue";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
        })

        //CLICK RED PANTS OPTIONS
        $('.red_pants').click(function(){
            if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='whiteShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isTrue";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='blackShirt_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isTrue";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (tankShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFlase";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            }
                
        }) 

        //CLICK WHITE SHORTS OPTIONS
        $('.white_shorts').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='whiteShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isTrue";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model' src='blackShirt_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isTrue";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (tankNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            } 
            else if (tankRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            } 
        })

        //CLICK BLACK TANK OPTIONS
        $('.black_tank').click(function(){
            if (blackShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_noPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse";
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            }
            else if (whiteShirtNoPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_noPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isTrue";
                tankRedPants = "isFalse";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            } 
            else if (blackShirtRedPants === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_redpants' src='tank_redPants_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isTrue";
                tankShorts = "isFalse";
            } 
            else if (whiteShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            } 
            else if (blackShirtandShorts === "isTrue"){
                document.getElementById('model').innerHTML = "<img id='mixmatch_model_tank' src='tank_Shorts_M.png'></img>"
                whiteShirtNoPants = "isFalse";
                blackShirtNoPants = "isFalse"; 
                blackShirtRedPants = "isFalse";
                whiteShirtRedPants = "isFalse";
                whiteShirtandShorts = "isFalse";
                blackShirtandShorts = "isFalse";
                tankNoPants = "isFalse";
                tankRedPants = "isFalse";
                tankShorts = "isTrue";
            } 
        })
        
    }

    //Get value of brand selected and display in text
    function showZaraSize(){
        document.getElementById('your_brand').innerHTML = "Which size do you buy from " + document.getElementById('zara').value + "?";
    }
    //Get value of brand selected
    function showHMSize(){
        document.getElementById('your_brand').innerHTML = "Which size do you buy from " + document.getElementById('hm').value + "?";
    }
    //Get value of brand selected
    function showAddidasSize(){
        document.getElementById('your_brand').innerHTML = "Which size do you buy from " + document.getElementById('addidas').value + "?";
    }

    var countrys = document.getElementsByName('country');
    // var sizes = document.getElementsByName('size');

        //Get value of country selected
        function displayRadioValue() {

            for(i = 0; i < countrys.length; i++) {
                if(countrys[i].checked)
                document.getElementById("your_location").innerHTML
                        = "Which brands do you buy from in "+countrys[i].value + "?";
            }
        }
        
        $('.cta').mouseenter(function(){
            TweenMax.to('.cta', 0.2, {y:4, repeat:3, yoyo:true});
        })
        $('.cta').mouseleave(function(){
            TweenMax.to('.cta', 0.2, {y:0});
        })

        // $('#fXS_shirt, #fS_shirt, #fM_shirt').mouseenter(function(){
        //     console.log('hover works');
        //     $(this).css('opacity', '100%');
        // })
        // $('#fXS_shirt, #fS_shirt').mouseleave(function(){
        //     console.log('hover works');
        //     $(this).css('opacity', '50%');
        // })

    // function displayCountrySize() {

    //     for(i = 0; i < sizes.length; i++) {
    //         if(sizes[i].checked)
    //         document.getElementById("yourOriginalSize").innerHTML
    //                 = "Your size in "+countrys[i].value + "<br> for this item is "+sizes[i].value;
    //     }
    // }

    // function displayBodyTypes() {
    //     var fXS = document.getElementById('fXS');

    //     fXS.addEventListener("click", () => {
    //         console.log('fXS clicked');
    //         $('#fXS_shirt_TC').css('opacity', "50%");
    //         $('#fM_shirt_TC').css('opacity', "50%");
    //         $('#fL_shirt_TC').css('opacity', "50%");
    //         $('#fXL_shirt_TC').css('opacity', "50%");
    //     })
    // }

    function displayResult() {

        //define values
        var sizeInputs = document.getElementsByName('size'); 
        var countryInputs = document.getElementsByName('country');
        // var bodyTypeInputs = document.getElementById('bodytype').value;

        let size, country, bodytype;

        // bodytype = bodyTypeInputs;

        // console.log(bodytype);

        //loop to get value and assign to variable
        for (var i = 0; i < sizeInputs.length; i++) {
            if(sizeInputs[i].checked)
                size = sizeInputs[i].value;
        }

        for (var i = 0; i < countryInputs.length; i++) {
            if(countryInputs[i].checked)
                country = countryInputs[i].value;
        }

        // for (var i = 0; i < bodyTypeInputs.length; i++) { // Use select list instead of image type inputs
        //     if(bodyTypeInputs[i].checked)
        //         bodytype = bodyTypeInputs[i].value; 
        // }

        //show text results for origin/inputed data
        document.getElementById("yourOriginalSize").innerHTML =
        "Your size in "+country + "<br> for this item is "+size;

        //show text results for TC based on data inputed
        if (size === "Extra Small"){
            document.getElementById("yourTCsize").innerHTML =
            "Your size in Jordan<br> for this item is Small";
        } else if (size === "Small"){
            document.getElementById("yourTCsize").innerHTML =
            "Your size in Jordan<br> for this item is Medium";
        } else if (size === "Medium"){
            document.getElementById("yourTCsize").innerHTML =
            "Your size in Jordan<br> for this item is Large";
        } else if (size === "Large"){
            document.getElementById("yourTCsize").innerHTML =
            "Your size in Jordan<br> for this item is Extra Large";
        } else if (size === "Extra Large"){
            document.getElementById("yourTCsize").innerHTML =
            "Your size in Jordan for this<br> item is 2x Extra Large";
        }

        //show picture results for TC based on inputed data 
        if(document.getElementById("yourTCsize").innerHTML ===
        "Your size in Jordan<br> for this item is Small") {
            $('#fXS_shirt_TC, #mXS_shirt_TC').css('opacity', "50%");
            $('#fM_shirt_TC, #mM_shirt_TC').css('opacity', "50%");
            $('#fL_shirt_TC, #mL_shirt_TC').css('opacity', "50%");
            $('#fXL_shirt_TC, #mXL_shirt_TC').css('opacity', "50%");
            $('#fXXL_shirt_TC, #mXXL_shirt_TC').css('opacity', "50%");
        } else if (document.getElementById("yourTCsize").innerHTML ===
        "Your size in Jordan<br> for this item is Medium") {
            $('#fXS_shirt_TC, #mXS_shirt_TC').css('opacity', "50%");
            $('#fS_shirt_TC, #mS_shirt_TC').css('opacity', "50%");
            $('#fL_shirt_TC, #mL_shirt_TC').css('opacity', "50%");
            $('#fXL_shirt_TC, #mXL_shirt_TC').css('opacity', "50%");
            $('#fXXL_shirt_TC, #mXXL_shirt_TC').css('opacity', "50%");
        } else if (document.getElementById("yourTCsize").innerHTML ===
        "Your size in Jordan<br> for this item is Large") {
            $('#fXS_shirt_TC, #mXS_shirt_TC').css('opacity', "50%");
            $('#fS_shirt_TC, #mS_shirt_TC').css('opacity', "50%");
            $('#fM_shirt_TC, #mM_shirt_TC').css('opacity', "50%");
            $('#fXL_shirt_TC, #mXL_shirt_TC').css('opacity', "50%");
            $('#fXXL_shirt_TC, #mXXL_shirt_TC').css('opacity', "50%");
        } else if (document.getElementById("yourTCsize").innerHTML ===
        "Your size in Jordan<br> for this item is Extra Large") {
            $('#fXS_shirt_TC, #mXS_shirt_TC').css('opacity', "50%");
            $('#fS_shirt_TC, #mS_shirt_TC').css('opacity', "50%");
            $('#fL_shirt_TC, #mL_shirt_TC').css('opacity', "50%");
            $('#fM_shirt_TC, #mM_shirt_TC').css('opacity', "50%");
            $('#fXXL_shirt_TC, #mXXL_shirt_TC').css('opacity', "50%");
        } else if (document.getElementById("yourTCsize").innerHTML ===
        "Your size in Jordan for this<br> item is 2x Extra Large") {
            $('#fXS_shirt_TC, #mXS_shirt_TC').css('opacity', "50%");
            $('#fS_shirt_TC, #mS_shirt_TC').css('opacity', "50%");
            $('#fL_shirt_TC, #mL_shirt_TC').css('opacity', "50%");
            $('#fM_shirt_TC, #mM_shirt_TC').css('opacity', "50%");
            $('#fXL_shirt_TC, #mXL_shirt_TC').css('opacity', "50%");
        }

        //show picture results for origin based on inputed data 
        if(document.getElementById("yourOriginalSize").innerHTML ===
        "Your size in "+country + "<br> for this item is Extra Small") {
            $('#fS_shirt, #mS_shirt').css('opacity', "50%");
            $('#fM_shirt, #mM_shirt').css('opacity', "50%");
            $('#fL_shirt, #mL_shirt').css('opacity', "50%");
            $('#fXL_shirt, #mXL_shirt').css('opacity', "50%");
        } else if(document.getElementById("yourOriginalSize").innerHTML ===
        "Your size in "+country + "<br> for this item is Small") {
            $('#fXS_shirt, #mXS_shirt').css('opacity', "50%");
            $('#fM_shirt, #mM_shirt').css('opacity', "50%");
            $('#fL_shirt, #mL_shirt').css('opacity', "50%");
            $('#fXL_shirt, #mXL_shirt').css('opacity', "50%");
        } else if(document.getElementById("yourOriginalSize").innerHTML ===
        "Your size in "+country + "<br> for this item is Medium") {
            $('#fXS_shirt, #mXS_shirt').css('opacity', "50%");
            $('#fS_shirt, #mS_shirt').css('opacity', "50%");
            $('#fL_shirt, #mL_shirt').css('opacity', "50%");
            $('#fXL_shirt, #mXL_shirt').css('opacity', "50%");
        } else if(document.getElementById("yourOriginalSize").innerHTML ===
        "Your size in "+country + "<br> for this item is Large") {
            $('#fXS_shirt, #mXS_shirt').css('opacity', "50%");
            $('#fS_shirt, #mS_shirt').css('opacity', "50%");
            $('#fM_shirt, #mM_shirt').css('opacity', "50%");
            $('#fXL_shirt, #mXL_shirt').css('opacity', "50%");
        } else if(document.getElementById("yourOriginalSize").innerHTML ===
        "Your size in "+country + "<br> for this item is Extra Large") {
            $('#fXS_shirt, #mXS_shirt').css('opacity', "50%");
            $('#fS_shirt, #mS_shirt').css('opacity', "50%");
            $('#fL_shirt, #mL_shirt').css('opacity', "50%");
            $('#fM_shirt, #mM_shirt').css('opacity', "50%");
        }

        // Data aggregated, decide output size      (Specific cases for demonstration, default case would be the original chosen size)

    }

});